"""Django settings for the order service (development values left in by mistake)."""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# expect: secret
SECRET_KEY = "dj4ng0-pr0d-k3y-9f8a7b6c5d4e3f2a1b0c"
# expect: debug
DEBUG = True
# expect: allowed-hosts
ALLOWED_HOSTS = ["*"]
# expect: cors
CORS_ALLOW_ALL_ORIGINS = True

INSTALLED_APPS = ["django.contrib.auth", "django.contrib.contenttypes", "orders"]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": "orders",
        "USER": "orders",
        # expect: secret
        "PASSWORD": "pg-Orders-2024",
        "HOST": "db.internal",
    }
}
