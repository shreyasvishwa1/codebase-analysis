"""Background tasks of the order service: imports, exports, tokens and reports."""

import hashlib
import json
import marshal
import os
import pickle
import random
import secrets
import ssl
import tempfile
import urllib.request
import xml.etree.ElementTree as ET

import defusedxml.ElementTree as SafeET
import yaml


def load_cart(blob: bytes):
    # expect: deserialization
    return pickle.loads(blob)


def load_settings(text: str):
    # expect: deserialization
    return yaml.load(text, Loader=yaml.Loader)


def load_compiled(blob: bytes):
    # expect: deserialization
    return marshal.loads(blob)


def load_settings_safely(text: str):
    # safe: deserialization
    return yaml.safe_load(text)


def load_cart_json(text: str):
    # safe: deserialization
    return json.loads(text)


def password_digest(password: str) -> str:
    # expect: weak-hash
    return hashlib.md5(password.encode()).hexdigest()


def api_key_fingerprint(key: str) -> str:
    # expect: weak-hash
    return hashlib.sha1(key.encode()).hexdigest()


def file_checksum(data: bytes) -> str:
    # safe: weak-hash
    return hashlib.sha256(data).hexdigest()


def cache_key(data: bytes) -> str:
    # safe: weak-hash
    return hashlib.md5(data, usedforsecurity=False).hexdigest()


def reset_token() -> str:
    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    # expect: weak-random
    return "".join(random.choice(alphabet) for _ in range(32))


def session_token() -> str:
    # safe: weak-random
    return secrets.token_urlsafe(32)


def shuffle_display_order(items: list) -> list:
    # safe: weak-random
    return random.sample(items, len(items))


def parse_invoice(xml_text: str):
    # expect: xxe
    return ET.fromstring(xml_text)


def parse_invoice_safely(xml_text: str):
    # safe: xxe
    return SafeET.fromstring(xml_text)


def export_path() -> str:
    # expect: temp-file
    return tempfile.mktemp(suffix=".csv")


def export_file():
    # safe: temp-file
    return tempfile.mkstemp(suffix=".csv")


def fetch_partner_feed(url: str) -> bytes:
    # expect: tls
    context = ssl._create_unverified_context()
    with urllib.request.urlopen(url, context=context, timeout=10) as response:
        return response.read()


def fetch_partner_feed_verified(url: str) -> bytes:
    # safe: tls
    context = ssl.create_default_context()
    with urllib.request.urlopen(url, context=context, timeout=10) as response:
        return response.read()


SMTP_USER = "orders@example.com"
# expect: secret
SMTP_PASSWORD = "Wint3r-Sale-2024!"
# safe: secret
SMTP_PASSWORD_FROM_ENV = os.environ.get("SMTP_PASSWORD")
# expect: secret
AWS_ACCESS_KEY_ID = "AKIAZ7Q3M5N2B8V4X6TR"
