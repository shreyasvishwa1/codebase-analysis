"""Order service: a small Flask app. Benchmark labels are comments above the labelled line."""

import ast
import os
import sqlite3
import subprocess

import jwt
import requests
from flask import Flask, redirect, render_template, render_template_string, request, send_file
from flask import send_from_directory, url_for

app = Flask(__name__)
DB_PATH = os.environ.get("ORDERS_DB", "orders.db")
UPLOADS = "/srv/uploads"
JWT_KEY = os.environ["JWT_KEY"]


def db():
    return sqlite3.connect(DB_PATH)


@app.route("/orders/by-customer")
def orders_by_customer():
    name = request.args["name"]
    cursor = db().cursor()
    # expect: sqli
    cursor.execute(f"SELECT id, total FROM orders WHERE customer = '{name}'")
    return {"orders": cursor.fetchall()}


@app.route("/orders/by-status")
def orders_by_status():
    status = request.args["status"]
    cursor = db().cursor()
    # expect: sqli
    cursor.execute("SELECT id FROM orders WHERE status = '%s'" % status)
    return {"orders": cursor.fetchall()}


@app.route("/orders/search")
def orders_search():
    term = request.args["q"]
    cursor = db().cursor()
    # expect: sqli
    cursor.execute("SELECT id FROM orders WHERE note LIKE '%" + term + "%'")
    return {"orders": cursor.fetchall()}


@app.route("/orders/<int:order_id>")
def order_detail(order_id):
    cursor = db().cursor()
    # safe: sqli
    cursor.execute("SELECT id, total FROM orders WHERE id = ?", (order_id,))
    return {"order": cursor.fetchone()}


@app.route("/orders/recent")
def orders_recent():
    limit = int(request.args.get("limit", 10))
    cursor = db().cursor()
    # safe: sqli
    cursor.execute("SELECT id FROM orders ORDER BY created DESC LIMIT ?", (limit,))
    return {"orders": cursor.fetchall()}


@app.route("/admin/ping")
def ping():
    host = request.args["host"]
    # expect: cmdi
    output = subprocess.check_output(f"ping -c 1 {host}", shell=True)
    return output


@app.route("/admin/disk")
def disk():
    folder = request.args["folder"]
    # expect: cmdi
    os.system("du -sh " + folder)
    return "ok"


@app.route("/admin/lookup")
def lookup():
    domain = request.args["domain"]
    # expect: cmdi
    return os.popen("nslookup " + domain).read()


@app.route("/admin/list")
def list_folder():
    folder = request.args["folder"]
    # safe: cmdi
    output = subprocess.run(["ls", "-l", "--", folder], capture_output=True, check=False)
    return output.stdout


@app.route("/calc")
def calc():
    expression = request.args["expr"]
    # expect: code-injection
    return str(eval(expression))


@app.route("/plugins/run", methods=["POST"])
def run_plugin():
    source = request.get_data(as_text=True)
    # expect: code-injection
    exec(source)
    return "done"


@app.route("/calc/literal")
def calc_literal():
    # safe: code-injection
    return str(ast.literal_eval(request.args["value"]))


@app.route("/files/download")
def download():
    name = request.args["name"]
    # expect: path-traversal
    return send_file(os.path.join(UPLOADS, name))


@app.route("/files/read")
def read_file():
    name = request.args["name"]
    # expect: path-traversal
    with open(UPLOADS + "/" + name) as handle:
        return handle.read()


@app.route("/files/safe-download")
def safe_download():
    # safe: path-traversal
    return send_from_directory(UPLOADS, request.args["name"])


@app.route("/preview")
def preview():
    target = request.args["url"]
    # expect: ssrf
    response = requests.get(target, timeout=10)
    return response.text


@app.route("/rates")
def rates():
    # safe: ssrf
    response = requests.get("https://api.example.com/rates", timeout=10)
    return response.json()


@app.route("/hello")
def hello():
    name = request.args.get("name", "guest")
    # expect: template-injection
    return render_template_string("<h1>Hello " + name + "</h1>")


@app.route("/hello-safe")
def hello_safe():
    # safe: template-injection
    return render_template("hello.html", name=request.args.get("name", "guest"))


@app.route("/login/done")
def login_done():
    # expect: open-redirect
    return redirect(request.args["next"])


@app.route("/logout")
def logout():
    # safe: open-redirect
    return redirect(url_for("hello"))


@app.route("/token/inspect")
def inspect_token():
    token = request.headers["Authorization"].removeprefix("Bearer ")
    # expect: jwt
    claims = jwt.decode(token, options={"verify_signature": False})
    return claims


@app.route("/token/check")
def check_token():
    token = request.headers["Authorization"].removeprefix("Bearer ")
    # safe: jwt
    claims = jwt.decode(token, JWT_KEY, algorithms=["HS256"])
    return claims


@app.route("/partner/status")
def partner_status():
    # expect: tls
    response = requests.get("https://partner.example.com/status", verify=False, timeout=10)
    return response.text


@app.route("/partner/health")
def partner_health():
    # safe: tls
    response = requests.get("https://partner.example.com/health", verify=True, timeout=10)
    return response.text


if __name__ == "__main__":
    # expect: debug
    app.run(debug=True)
