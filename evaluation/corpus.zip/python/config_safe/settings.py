"""Django settings read from the environment."""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# safe: secret
SECRET_KEY = os.environ["DJANGO_SECRET_KEY"]
# safe: debug
DEBUG = os.environ.get("DJANGO_DEBUG") == "1"
# safe: allowed-hosts
ALLOWED_HOSTS = ["orders.example.com"]
# safe: cors
CORS_ALLOWED_ORIGINS = ["https://shop.example.com"]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": "orders",
        "USER": "orders",
        # safe: secret
        "PASSWORD": os.environ["DB_PASSWORD"],
        "HOST": "db.internal",
    }
}
