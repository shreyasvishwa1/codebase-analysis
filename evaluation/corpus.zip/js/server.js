// Storefront API: a small Express app. Benchmark labels are comments above the labelled line.
const express = require("express");
const { exec, execFile } = require("child_process");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const https = require("https");
const axios = require("axios");
const jwt = require("jsonwebtoken");
const mysql = require("mysql2");

const app = express();
app.use(express.json());
const db = mysql.createConnection({ host: "db.internal", user: "shop", password: process.env.DB_PASSWORD });
const PUBLIC_DIR = path.join(__dirname, "public");
const JWT_KEY = process.env.JWT_KEY;

app.get("/products", (req, res) => {
  // expect: sqli
  db.query("SELECT * FROM products WHERE category = '" + req.query.category + "'", (err, rows) => res.json(rows));
});

app.get("/products/search", (req, res) => {
  // expect: sqli
  db.query(`SELECT * FROM products WHERE name LIKE '%${req.query.q}%'`, (err, rows) => res.json(rows));
});

app.get("/products/:id", (req, res) => {
  // safe: sqli
  db.query("SELECT * FROM products WHERE id = ?", [req.params.id], (err, rows) => res.json(rows));
});

app.get("/admin/ping", (req, res) => {
  // expect: cmdi
  exec(`ping -c 1 ${req.query.host}`, (err, stdout) => res.send(stdout));
});

app.get("/admin/disk", (req, res) => {
  // expect: cmdi
  exec("du -sh " + req.query.folder, (err, stdout) => res.send(stdout));
});

app.get("/admin/list", (req, res) => {
  // safe: cmdi
  execFile("ls", ["-l", "--", req.query.folder], (err, stdout) => res.send(stdout));
});

app.post("/calc", (req, res) => {
  // expect: code-injection
  // expect: xss
  res.send(String(eval(req.body.expression)));
});

app.post("/rules", (req, res) => {
  // expect: code-injection
  const rule = new Function("order", req.body.rule);
  // expect: xss
  res.send(String(rule({ total: 10 })));
});

app.post("/settings", (req, res) => {
  // safe: code-injection
  const settings = JSON.parse(req.body.settings);
  res.json(settings);
});

app.get("/files", (req, res) => {
  // expect: path-traversal
  res.sendFile(path.join(PUBLIC_DIR, req.query.name));
});

app.get("/files/raw", (req, res) => {
  // expect: path-traversal
  fs.readFile(PUBLIC_DIR + "/" + req.query.name, "utf8", (err, text) => res.send(text));
});

app.get("/files/safe", (req, res) => {
  // safe: path-traversal
  res.sendFile(path.basename(req.query.name), { root: PUBLIC_DIR });
});

app.get("/preview", async (req, res) => {
  // expect: ssrf
  const response = await axios.get(req.query.url);
  // expect: xss
  res.send(response.data);
});

app.get("/rates", async (req, res) => {
  // safe: ssrf
  const response = await axios.get("https://api.example.com/rates");
  res.json(response.data);
});

app.get("/login/done", (req, res) => {
  // expect: open-redirect
  res.redirect(req.query.next);
});

app.get("/logout", (req, res) => {
  // safe: open-redirect
  res.redirect("/");
});

app.get("/greet", (req, res) => {
  // expect: xss
  res.send("<h1>Hello " + req.query.name + "</h1>");
});

app.get("/greet-safe", (req, res) => {
  // safe: xss
  res.json({ greeting: "Hello", name: req.query.name });
});

app.get("/token/check", (req, res) => {
  const token = req.headers.authorization.replace("Bearer ", "");
  // expect: jwt
  const claims = jwt.verify(token, JWT_KEY, { algorithms: ["HS256", "none"] });
  res.json(claims);
});

app.get("/token/verify", (req, res) => {
  const token = req.headers.authorization.replace("Bearer ", "");
  // safe: jwt
  const claims = jwt.verify(token, JWT_KEY, { algorithms: ["HS256"] });
  res.json(claims);
});

app.use((req, res, next) => {
  // expect: cors
  res.setHeader("Access-Control-Allow-Origin", "*");
  next();
});

app.use((req, res, next) => {
  // safe: cors
  res.setHeader("Access-Control-Allow-Origin", "https://shop.example.com");
  next();
});

function passwordDigest(password) {
  // expect: weak-hash
  return crypto.createHash("md5").update(password).digest("hex");
}

function fileChecksum(data) {
  // safe: weak-hash
  return crypto.createHash("sha256").update(data).digest("hex");
}

function resetToken() {
  // expect: weak-random
  return Math.random().toString(36).slice(2);
}

function sessionToken() {
  // safe: weak-random
  return crypto.randomBytes(32).toString("hex");
}

// expect: tls
const partnerAgent = new https.Agent({ rejectUnauthorized: false });
// safe: tls
const verifiedAgent = new https.Agent({ rejectUnauthorized: true });

// expect: secret
const PAYMENT_API_SECRET = "pay_9f8e7d6c5b4a39281706f5e4d3c2b1a0";
// safe: secret
const PAYMENT_API_SECRET_FROM_ENV = process.env.PAYMENT_API_SECRET;

module.exports = { app, passwordDigest, fileChecksum, resetToken, sessionToken, partnerAgent, verifiedAgent };
app.listen(3000);
