// Storefront page script. Benchmark labels are comments above the labelled line.
const params = new URLSearchParams(window.location.search);

function showSearchTerm() {
  const banner = document.getElementById("banner");
  // expect: xss
  banner.innerHTML = "Results for " + params.get("q");
}

function showSearchTermSafely() {
  const banner = document.getElementById("banner");
  // safe: xss
  banner.textContent = "Results for " + params.get("q");
}

function showWelcome() {
  // expect: xss
  document.write("<p>Welcome back, " + decodeURIComponent(window.location.hash.slice(1)) + "</p>");
}

function addReview(review) {
  const list = document.getElementById("reviews");
  // expect: xss
  list.insertAdjacentHTML("beforeend", "<li>" + review.text + "</li>");
}

function addReviewSafely(review) {
  const item = document.createElement("li");
  // safe: xss
  item.textContent = review.text;
  document.getElementById("reviews").appendChild(item);
}

function runPromoScript() {
  // expect: code-injection
  eval(params.get("promo"));
}

function continueAfterLogin() {
  // expect: open-redirect
  window.location.href = params.get("next");
}

function goHome() {
  // safe: open-redirect
  window.location.href = "/";
}

showSearchTerm();
showSearchTermSafely();
showWelcome();
runPromoScript();
