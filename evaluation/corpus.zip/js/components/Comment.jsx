// Product review components. Benchmark labels are comments above the labelled line.
import React from "react";

export function Comment({ comment }) {
  return (
    <div className="comment">
      <strong>{comment.author}</strong>
      {/* expect: xss */}
      <div dangerouslySetInnerHTML={{ __html: comment.body }} />
    </div>
  );
}

export function SafeComment({ comment }) {
  return (
    <div className="comment">
      <strong>{comment.author}</strong>
      {/* safe: xss */}
      <div>{comment.body}</div>
    </div>
  );
}
