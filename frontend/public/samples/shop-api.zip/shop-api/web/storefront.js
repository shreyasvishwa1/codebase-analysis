// Storefront logic. DELIBERATELY INSECURE test code: never run it.
const childProcess = require('child_process')
const jwt = require('jsonwebtoken')
const https = require('https')

const apiKey = "k7Hd92LsQp0Zx81mWq"

function showReview(review) {
  document.getElementById('review').innerHTML = review.text
}

function banner(message) {
  document.write('<p>' + message + '</p>')
}

function runPromo(code) {
  return eval(code)
}

function findOrder(db, id) {
  return db.query("SELECT * FROM orders WHERE id = " + id)
}

function findCustomer(db, email) {
  return db.query(`SELECT * FROM customers WHERE email = '${email}'`)
}

function archive(dir) {
  childProcess.exec(`tar czf archive.tgz ${dir}`)
}

const agent = new https.Agent({ rejectUnauthorized: false })

function readToken(token) {
  return jwt.verify(token, 'key', { algorithms: ['none'] })
}

function allowAll(res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
}

module.exports = { showReview, banner, runPromo, findOrder, findCustomer, archive, agent, readToken, allowAll, apiKey }
