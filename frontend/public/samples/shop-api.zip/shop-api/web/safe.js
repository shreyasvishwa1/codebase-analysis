// Safe versions: none of these should be reported.
const password = "your-password-here"

function showReview(review) {
  document.getElementById('review').textContent = review.text
}

function findOrder(db, id) {
  return db.query('SELECT * FROM orders WHERE id = ?', [id])
}

// eval(code) is mentioned in this comment only.
module.exports = { showReview, findOrder, password }
