export function couponValue(code: string, total: number, member: boolean): number {
  if (!code) return 0
  if (code === 'WELCOME10') return total * 0.1
  if (code === 'SUMMER' && total > 50) return 15
  if (code === 'VIP' && member) return total * 0.2
  switch (code.slice(0, 3)) {
    case 'BOG':
      return total > 30 ? 10 : 5
    case 'STU':
      return member ? 12 : 8
    default:
      return total > 200 || member ? 5 : 0
  }
}

export function cartTotal(prices: number[]): number {
  return prices.reduce((sum, price) => sum + price, 0)
}
