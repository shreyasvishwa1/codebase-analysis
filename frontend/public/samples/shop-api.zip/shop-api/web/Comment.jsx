export function Comment({ html }) {
  return <div className="comment" dangerouslySetInnerHTML={{ __html: html }} />
}
