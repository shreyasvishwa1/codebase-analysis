# Security testing guide

Upload this ZIP, open the repository, run **Full analysis**, then open **Security** (in the
sidebar, or the Security tab of the repository). Every key and password here is fake.

## What you should see: 36 findings in the code
(plus one finding per published vulnerability of the dependencies, under OWASP A06; see
Dependencies below: 11 of them in November 2026)

- Critical 2 · High 12 · Medium 13 · Low 9
- Confirmed 18 · Potential 18
- Bandit (Python) finds 16 of them; CodeBase Analysis's own checks find 20.

### Critical (both confirmed)
- config/settings.py line 7: AWS access key committed (AWS's documentation example key)
- keys/server.pem line 1: private key committed

### High (12)
- .env: environment file committed (confirmed; values are never shown)
- shop/db.py: shell=True (B602), weak MD5 hash (B324), verify=False (B501), Flask debug
  mode (B201)
- web/storefront.js: eval(), TLS verification off, JWT 'none' algorithm (all confirmed);
  a hard-coded API key, SQL built with + and with a template literal, a shell command built
  from a template literal (potential)

### Medium (13)
- shop/db.py: pickle.loads (B301), yaml.load (B506), eval (B307), SQL in an f-string (B608),
  requests without a timeout (B113)
- config/settings.py: DEBUG = True, ALLOWED_HOSTS = ['*'], CORS allow-all
- web/storefront.js: innerHTML, document.write, CORS '*'
- web/Comment.jsx: dangerouslySetInnerHTML
- Dockerfile: runs as root (no USER)

### Low (9)
- shop/db.py: pickle and subprocess imported (B403, B404), random for a token (B311),
  subprocess call and partial path (B603, B607), try/except/pass (B110), hard-coded
  password (B105, value never shown)
- Dockerfile: unpinned base image (python:latest), ADD from a URL

## Things to try
- Click a severity card, a confidence badge, an OWASP bar or a file to filter the list.
- Expand a finding: why it matters, how to fix it, its CWE link and "Open in explorer".
- Search for "pickle" or "B602".

## Must NOT be reported (safe versions)
- web/safe.js: parameterized query, textContent, a placeholder password, eval in a comment
- .env.example: placeholder values
- shop/safe.py: yaml.safe_load, parameterized SQL, hashlib.sha256

## Dependencies (open the Dependencies tab)
- 4 declared: flask==2.0.1, requests==2.25.0 and pyyaml==5.3 (requirements.txt) and
  jsonwebtoken 8.5.1 (package.json). All are pinned and all are behind the latest release.
- All 4 have published vulnerabilities (OSV.dev). In November 2026: 11 in total, including
  two Critical ones in PyYAML 5.3 (CVE-2020-1747, CVE-2020-14343; fixed in 5.3.1 and 5.4).
  New advisories are published over time, so later runs can show more.
- Expand a dependency to see each advisory, its CVSS score, the fixed version and a link
  to OSV.dev. The same vulnerabilities appear on the Security page under A06.

## Complexity (open the Complexity tab)
- shop/pricing.py: `shipping_cost` has cyclomatic complexity 23 (High) and
  `loyalty_points` 12 (Medium); every other function is Low.
- web/cart.ts: `couponValue` has complexity 13 (Medium).
- Python files get Radon's maintainability index; JavaScript and TypeScript files get the
  same formula estimated from tokens (marked "est.").
