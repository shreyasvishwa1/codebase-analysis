# Shop API

A small online-shop backend (Python) with a JavaScript storefront. It is a test repository
for CodeBase Analysis and contains deliberate security problems. Every key and password in
it is fake. Open SECURITY-TESTING-GUIDE.md for what the security analysis should find.
