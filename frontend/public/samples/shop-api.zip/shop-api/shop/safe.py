"""Safe versions of the same operations: none of these should be reported."""

import hashlib
import sqlite3

import yaml


def find_user(name):
    conn = sqlite3.connect("shop.db")
    return conn.execute("SELECT * FROM users WHERE name = ?", (name,)).fetchall()


def load_config(text):
    return yaml.safe_load(text)


def fingerprint(data):
    return hashlib.sha256(data).hexdigest()
