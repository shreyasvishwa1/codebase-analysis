"""Shipping and loyalty rules. Deliberately complex test code for the complexity analysis."""


def shipping_cost(order):
    """Shipping cost of an order."""
    cost = 0
    if order.express:
        cost += 15
    if order.weight > 20:
        cost += 10
    elif order.weight > 10:
        cost += 6
    elif order.weight > 5:
        cost += 3
    if order.country == "US":
        cost += 0
    elif order.country in ("CA", "MX"):
        cost += 8
    elif order.country in ("GB", "DE", "FR"):
        cost += 12
    else:
        cost += 20
    if order.fragile and not order.insured:
        cost += 5
    for item in order.items:
        if item.oversized:
            cost += 4
        if item.hazardous:
            cost += 9
        if item.refrigerated and order.express:
            cost += 7
    if order.member:
        cost -= 5
    if order.coupon == "FREESHIP" or order.total > 100:
        cost = 0
    if order.gift_wrap:
        cost += 2
    if order.saturday_delivery:
        cost += 6
    if order.signature_required:
        cost += 1
    if order.po_box:
        cost += 3
    while cost < 0:
        cost += 1
    return cost


def loyalty_points(customer, total):
    """Points earned for an order."""
    points = int(total)
    if customer.tier == "gold":
        points *= 3
    elif customer.tier == "silver":
        points *= 2
    if customer.birthday_month and total > 50:
        points += 100
    if customer.referrals > 10:
        points += 50
    elif customer.referrals > 5:
        points += 20
    if customer.years > 5 or customer.vip:
        points += 30
    for _ in range(customer.reviews):
        points += 1
    if customer.newsletter:
        points += 5
    if customer.app_user:
        points += 10
    return points


def tax(total, rate):
    """Sales tax."""
    return round(total * rate, 2)
