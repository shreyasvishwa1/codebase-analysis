"""Data access for the shop. DELIBERATELY INSECURE test code: never run it."""

import hashlib
import pickle
import random
import sqlite3
import subprocess

import requests
import yaml
from flask import Flask

app = Flask(__name__)
ADMIN_PASSWORD = "Sup3rS3cr3t!2024"


def find_user(name):
    conn = sqlite3.connect("shop.db")
    return conn.execute(f"SELECT * FROM users WHERE name = '{name}'").fetchall()


def load_cart(blob):
    return pickle.loads(blob)


def load_config(text):
    return yaml.load(text)


def backup(folder):
    subprocess.call("tar czf backup.tgz " + folder, shell=True)


def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()


def fetch_rates():
    return requests.get("https://rates.example.com/latest", verify=False)


def calculate(expression):
    return eval(expression)


def reset_token():
    return str(random.random())


def quietly_delete(path):
    try:
        subprocess.run(["rm", path], check=True)
    except Exception:
        pass


if __name__ == "__main__":
    app.run(debug=True)
